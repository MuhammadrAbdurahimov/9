﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using WpfApp1.Models;

namespace WpfApp1
{
    internal class Helpel
    {
        private static Entities _context; // Статическая приватная переменная для хранения контекста модели данных

        /// <summary>
        /// Метод для получения контекста данных, необходимого для подключения к базе данных.
        /// </summary>
        /// <returns>Контекст данных типа Entities.</returns>
        public static Entities GetContext()
        {
            // Проверка, установлено ли подключение; если нет, создается новое подключение
            if (_context == null)
            {
                _context = new Entities(); // Создание нового подключения к БД
            }
            return _context; // Возвращение текущего подключения
        }

        /// <summary>
        /// Метод для добавления новой записи о пользователе в таблицу Users базы данных.
        /// </summary>
        /// <param name="user">Объект типа User, содержащий информацию о новом пользователе.</param>
        public void CreateUser(User user)
        {
            var context = GetContext();
            context.User.Add(user); // Добавление записи нового пользователя в таблицу Users
            context.SaveChanges(); // Сохранение изменений в БД
        }

        /// <summary>
        /// Метод для обновления записи о пользователе в таблице Users базы данных.
        /// </summary>
        /// <param name="user">Объект типа User, представляющий измененную сущность пользователя.</param>
        public void UpdateUser(User user)
        {
            var context = GetContext();
            context.Entry(user).State = EntityState.Modified;
            context.SaveChanges(); // Сохранение измененной сущности в БД
        }

        /// <summary>
        /// Метод для удаления записи о пользователе из таблицы Users базы данных.
        /// </summary>
        /// <param name="idUser">Целое число, представляющее идентификатор пользователя, который необходимо удалить.</param>
        public void RemoveUser(int idUser)
        {
            var context = GetContext();
            var user = context.User.Find(idUser); // Поиск записи пользователя по его id
            if (user != null)
            {
                context.User.Remove(user); // Удаление записи найденного пользователя
                context.SaveChanges(); // Сохранение изменений в БД
            }
        }

        /// <summary>
        /// Метод для фильтрации записей пользователей по имени.
        /// </summary>
        /// <returns>Список пользователей, чьи имена начинаются с буквы 'M' или 'A'.</returns>
        public List<User> FiltrUsers()
        {
            var context = GetContext();
            return context.User.Where(x => x.Name.StartsWith("M") || x.Name.StartsWith("A")).ToList();
        }

        /// <summary>
        /// Метод для сортировки записей пользователей по имени.
        /// </summary>
        /// <returns>Список пользователей, отсортированных по именам в порядке возрастания.</returns>
        public List<User> SortUsers()
        {
            var context = GetContext();
            return context.User.OrderBy(x => x.Name).ToList();
        }

        /// <summary>
        /// Метод для добавления новой записи о сотруднике в таблицу Employees базы данных.
        /// </summary>
        /// <param name="employee">Объект типа Employee, содержащий информацию о новом сотруднике.</param>
        public void CreateEmployee(Employee employee)
        {
            var context = GetContext();
            context.Employee.Add(employee); // Добавление записи нового сотрудника в таблицу Employees
            context.SaveChanges(); // Сохранение изменений в БД
        }

        /// <summary>
        /// Метод для обновления записи о сотруднике в таблице Employees базы данных.
        /// </summary>
        /// <param name="employee">Объект типа Employee, представляющий измененную сущность сотрудника.</param>
        public void UpdateEmployee(Employee employee)
        {
            var context = GetContext();
            context.Entry(employee).State = EntityState.Modified;
            context.SaveChanges(); // Сохранение измененной сущности в БД
        }

        /// <summary>
        /// Метод для удаления записи о сотруднике из таблицы Employees базы данных.
        /// </summary>
        /// <param name="idEmployee">Целое число, представляющее идентификатор сотрудника, который необходимо удалить.</param>
        public void RemoveEmployee(int idEmployee)
        {
            var context = GetContext();
            var employee = context.Employee.Find(idEmployee); // Поиск записи сотрудника по его id
            if (employee != null)
            {
                context.Employee.Remove(employee); // Удаление записи найденного сотрудника
                context.SaveChanges(); // Сохранение изменений в БД
            }
        }
    }
}