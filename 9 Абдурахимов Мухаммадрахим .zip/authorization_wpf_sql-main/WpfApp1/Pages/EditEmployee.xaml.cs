﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WpfApp1.Models;

namespace WpfApp1.Pages
{
    public partial class EditEmployee : Page
    {
        private Employee currentEmployee;
        private Authorization currentAuth;
        private Entities db = new Entities();
        private bool isEditMode = false;

        public EditEmployee(Employee emp)
        {
            InitializeComponent();

            if (emp != null)
            {
                isEditMode = true;
                btnDelete.Visibility = Visibility.Visible;

                currentEmployee = db.Employee.FirstOrDefault(e => e.Id_Employee == emp.Id_Employee);
                currentAuth = db.Authorization.FirstOrDefault(a => a.id_authorization == currentEmployee.id_authorization);

                txtSurName.Text = currentEmployee.SurName;
                txtName.Text = currentEmployee.Name;
                txtFathName.Text = currentEmployee.FathName;
                txtPassNumber.Text = currentEmployee.PassNumber;
                txtAdress.Text = currentEmployee.Adress;
                txtPhone.Text = currentEmployee.Phone;

                txtLogin.Text = currentAuth?.login;
                txtParol.Password = currentAuth?.parol;
            }
            else
            {
                currentEmployee = new Employee();
                currentAuth = new Authorization();
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtParol.Password))
            {
                MessageBox.Show("Логин и пароль обязательны.");
                return;
            }

            try
            {
                if (!isEditMode)
                {
                    currentAuth.login = txtLogin.Text;
                    currentAuth.parol = txtParol.Password;
                    currentAuth.id_Position = 1;

                    db.Authorization.Add(currentAuth);
                    db.SaveChanges();

                    currentEmployee.id_authorization = currentAuth.id_authorization;
                    db.Employee.Add(currentEmployee);
                }
                else
                {
                    var auth = db.Authorization.FirstOrDefault(a => a.id_authorization == currentEmployee.id_authorization);
                    if (auth != null)
                    {
                        auth.login = txtLogin.Text;
                        auth.parol = txtParol.Password;
                    }
                }

                currentEmployee.SurName = txtSurName.Text;
                currentEmployee.Name = txtName.Text;
                currentEmployee.FathName = txtFathName.Text;
                currentEmployee.PassNumber = txtPassNumber.Text;
                currentEmployee.Adress = txtAdress.Text;
                currentEmployee.Phone = txtPhone.Text;

                db.SaveChanges();
                MessageBox.Show("Сотрудник сохранён.");
                NavigationService.GoBack();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var confirm = MessageBox.Show("Удалить сотрудника?", "Подтверждение", MessageBoxButton.YesNo);
            if (confirm == MessageBoxResult.Yes)
            {
                var emp = db.Employee.FirstOrDefault(x => x.Id_Employee == currentEmployee.Id_Employee);
                if (emp != null) db.Employee.Remove(emp);

                var auth = db.Authorization.FirstOrDefault(x => x.id_authorization == currentEmployee.id_authorization);
                if (auth != null) db.Authorization.Remove(auth);

                db.SaveChanges();
                MessageBox.Show("Сотрудник удалён.");
                NavigationService.GoBack();
            }
        }
    }
}
