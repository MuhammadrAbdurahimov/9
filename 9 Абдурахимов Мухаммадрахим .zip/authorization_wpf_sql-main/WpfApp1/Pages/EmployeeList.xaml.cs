﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp1.Models;

namespace WpfApp1.Pages
{
    public partial class EmployeeList : Page
    {
        private List<Employee> allEmployees;
        private Entities db = new Entities();
        private Authorization _user;
        private string _role;

        
        public EmployeeList(Authorization user, string role)
        {
            InitializeComponent();
            _user = user;
            _role = role;

            LoadEmployees();
        }

        
        private void LoadEmployees()
        {
            allEmployees = db.Employee.ToList();
            UpdateList(allEmployees);
        }

        
        private void UpdateList(List<Employee> list)
        {
            LViewEmployee.ItemsSource = list.Select(emp => new EmployeeDisplay
            {
                FullName = $"{emp.SurName} {emp.Name} {emp.FathName}",
                Info = $"Паспорт: {emp.PassNumber}, Адрес: {emp.Adress}",
                Data = emp
            }).ToList();
        }

       
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = txtSearch.Text.ToLower();

            var filtered = allEmployees.Where(emp =>
                (emp.SurName + " " + emp.Name + " " + emp.FathName).ToLower().Contains(searchText)).ToList();

            UpdateList(filtered);
        }

        
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditEmployee(null));
        }

       
        private void LViewEmployee_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (LViewEmployee.SelectedItem is EmployeeDisplay selected)
            {
                NavigationService.Navigate(new EditEmployee(selected.Data));
            }
        }
    }

    
    public class EmployeeDisplay
    {
        public string FullName { get; set; }
        public string Info { get; set; }
        public Employee Data { get; set; }
    }
}
