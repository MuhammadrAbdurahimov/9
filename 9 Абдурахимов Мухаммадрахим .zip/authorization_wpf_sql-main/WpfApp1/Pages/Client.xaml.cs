﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WpfApp1.Models;

namespace WpfApp1.Pages
{
    public partial class Client : Page
    {
        private static Entities db;

        public Client(Authorization user, string role)
        {
            InitializeComponent();
            db = new Entities();
            LoadData();
            GreetUser(user);
        }

        private void LoadData()
        {
            try
            {

                if (db == null)
                {
                    db = new Entities();
                }


                var items = db.InsuranceCases.ToList();
                ApplyFiltersAndSorting(items);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void ApplyFiltersAndSorting(List<InsuranceCases> items)
        {

            string searchText = txtSearch.Text.ToLower();
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                items = items
                    .Where(x =>
                        x.Description.ToLower().Contains(searchText.ToLower()) ||
                        x.Id_User.ToString().Contains(searchText.ToLower()) ||
                        x.Id_Employee.ToString().Contains(searchText.ToLower())
                    )
                    .ToList();
            }

            switch (cmbSorting.SelectedIndex)
            {
                case 0:

                    break;
                case 1:
                    items = items.OrderBy(x => x.DateofCase).ToList();
                    break;
                case 2:
                    items = items.OrderByDescending(x => x.DateofCase).ToList();
                    break;
            }


            if (cmbFilter != null)
            {
                switch (cmbFilter.SelectedIndex)
                {
                    case 1:
                        items = items.Where(x => x.User != null).ToList();
                        break;
                    case 2:
                        items = items.Where(x => x.Id_Employee != null).ToList();
                        break;
                }
            }
            else
            {
                MessageBox.Show("Ошибка: cmbFilter не инициализирован.");
            }


            if (LViewProduct != null)
            {
                LViewProduct.ItemsSource = items;
                lblCount.Content = $"{items.Count} из {db.InsuranceCases.Count()}";
            }
            else
            {
                MessageBox.Show("Ошибка: LViewProduct не инициализирован.");
            }
        }

        private void GreetUser(Authorization user)
        {
            DateTime currentTime = DateTime.Now;
            string greeting;

            if (currentTime.Hour >= 10 && currentTime.Hour < 12)
            {
                greeting = "утро";
            }
            else if (currentTime.Hour >= 12 && currentTime.Hour < 17)
            {
                greeting = "день";
            }
            else if (currentTime.Hour >= 17 && currentTime.Hour < 22)
            {
                greeting = "вечер";
            }
            else
            {
                greeting = "время";
            }

            text1.Content = $"Доброе {greeting}!, {user.login}";
        }

        private void cmbSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LViewProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}